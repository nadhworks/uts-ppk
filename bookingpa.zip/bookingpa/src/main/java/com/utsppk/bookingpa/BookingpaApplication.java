package com.utsppk.bookingpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingpaApplication.class, args);
	}

}
